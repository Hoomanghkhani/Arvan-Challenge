# ArvanCloud WordPress Store Plugin

This standalone WordPress plugin allows you to sell ArvanCloud products (Cloud Server, CDN, Object Storage) directly on your website without relying on WooCommerce or any specific theme.

## Features
- 🚀 **Standalone:** No dependencies on WooCommerce, Elementor, or specific themes.
- 📱 **Responsive UI:** Built with Vue 3 and Tailwind CSS for a seamless experience on desktop and mobile.
- 🔌 **API Integration:** Connects to ArvanCloud's API securely via WordPress REST API.
- 🛒 **Products Included:** Cloud Server (ECC), CDN, Object Storage.

## Installation & Setup

1. **Upload the Plugin:**
   Copy the `arvan-store` folder into your WordPress `wp-content/plugins/` directory.

2. **Activate the Plugin:**
   Go to the WordPress Admin Panel -> Plugins -> Installed Plugins, and activate "ArvanCloud Store".

3. **Configure API Key:**
   - In the WordPress Admin menu, go to **Arvan Orders -> Settings**.
   - Enter your ArvanCloud API Key and save.

4. **Display the Store:**
   Create a new Page or Post in WordPress and add the following shortcode where you want the store to appear:
   `[arvan_store]`

## How to Record the Demo Video (Hackathon Requirement)
To meet the hackathon requirements, your 5+ minute video should cover:
1. **Introduction:** Introduce yourself and the plugin's goal.
2. **Installation:** Show how the plugin is installed and activated independently.
3. **Configuration:** Show the settings page where the API key is entered.
4. **Desktop Demo:** Open the page with the `[arvan_store]` shortcode on a laptop. Go through the process of selecting a Cloud Server, configuring it (OS, flavor, disk), and checking out.
5. **Mobile Demo:** Use Chrome DevTools (Device Toggle) or your actual phone to show the responsive UI. Buy a CDN or Object Storage product on the mobile view.
6. **Backend View:** Show the "Arvan Orders" menu in the WP Admin to prove that the orders are being saved in the database correctly.
